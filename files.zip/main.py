"""
CBD SERVER INVENTORY — FastAPI Backend
======================================
Run: uvicorn main:app --host 0.0.0.0 --port 8000
"""

from fastapi import FastAPI, Depends, HTTPException, status, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import os, asyncpg, json

app = FastAPI(title="CBD Server Inventory API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://cbd-portal.cbd.local"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security  = HTTPBearer()
API_TOKEN = os.environ["CBD_API_TOKEN"]
DB_DSN    = os.environ["DATABASE_URL"]

@app.on_event("startup")
async def startup():
    app.state.pool = await asyncpg.create_pool(DB_DSN, min_size=2, max_size=10)

@app.on_event("shutdown")
async def shutdown():
    await app.state.pool.close()

async def get_db():
    async with app.state.pool.acquire() as conn:
        yield conn

def verify_token(creds: HTTPAuthorizationCredentials = Depends(security)):
    if creds.credentials != API_TOKEN:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid token")

# ── Models ────────────────────────────────────────────────────────────────────
class ServerUpdate(BaseModel):
    hostname:               str
    fqdn:                   Optional[str]
    ip_address:             str
    os_name:                Optional[str]
    os_version:             Optional[str]
    kernel:                 Optional[str]
    architecture:           Optional[str]
    cpu_count:              Optional[int]
    cpu_model:              Optional[str]
    memory_gb:              Optional[float]
    memory_free_gb:         Optional[float]
    swap_gb:                Optional[float]
    disk_details:           Optional[str]
    uptime:                 Optional[str]
    last_reboot:            Optional[str]
    logged_in_users:        Optional[List[str]]
    local_users:            Optional[List[str]]
    sudo_members:           Optional[str]
    running_services_count: Optional[int]
    selinux_status:         Optional[str]
    timezone:               Optional[str]

class ServerPatch(BaseModel):
    patch_status:    Optional[str]
    enabled_flag:    Optional[bool]
    cluster:         Optional[str]
    power_state:     Optional[str]
    last_patch_date: Optional[str]

# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.post("/api/server-update")
async def server_update(payload: ServerUpdate, db=Depends(get_db), _=Depends(verify_token)):
    await db.execute("""
        INSERT INTO servers (
            hostname, fqdn, ip_address, os_name, os_version, kernel,
            architecture, cpu_count, cpu_model, memory_gb, memory_free_gb,
            swap_gb, disk_details, uptime, last_reboot, logged_in_users,
            local_users, sudo_members, selinux_status, timezone, last_seen
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,NOW())
        ON CONFLICT (hostname) DO UPDATE SET
            ip_address=EXCLUDED.ip_address, os_name=EXCLUDED.os_name,
            os_version=EXCLUDED.os_version, kernel=EXCLUDED.kernel,
            cpu_count=EXCLUDED.cpu_count, memory_gb=EXCLUDED.memory_gb,
            disk_details=EXCLUDED.disk_details, uptime=EXCLUDED.uptime,
            last_reboot=EXCLUDED.last_reboot, last_seen=NOW()
    """,
        payload.hostname, payload.fqdn, payload.ip_address,
        payload.os_name, payload.os_version, payload.kernel,
        payload.architecture, payload.cpu_count, payload.cpu_model,
        payload.memory_gb, payload.memory_free_gb, payload.swap_gb,
        payload.disk_details, payload.uptime, payload.last_reboot,
        json.dumps(payload.logged_in_users or []),
        json.dumps(payload.local_users or []),
        payload.sudo_members or "",
        payload.selinux_status, payload.timezone,
    )
    return {"status": "ok", "hostname": payload.hostname}


@app.get("/api/servers")
async def list_servers(
    search:  Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    os_name: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, le=500),
    db=Depends(get_db), _=Depends(verify_token)
):
    conditions, params = ["enabled_flag = true"], []
    i = 1
    if search:
        conditions.append(f"(hostname ILIKE ${i} OR ip_address ILIKE ${i})")
        params.append(f"%{search}%"); i += 1
    if cluster:
        conditions.append(f"cluster = ${i}"); params.append(cluster); i += 1
    if os_name:
        conditions.append(f"os_name = ${i}"); params.append(os_name); i += 1
    where = "WHERE " + " AND ".join(conditions)
    rows  = await db.fetch(f"SELECT * FROM servers {where} ORDER BY hostname LIMIT ${i} OFFSET ${i+1}", *params, size, (page-1)*size)
    count = await db.fetchval(f"SELECT COUNT(*) FROM servers {where}", *params)
    return {"total": count, "page": page, "data": [dict(r) for r in rows]}


@app.get("/api/servers/{hostname}")
async def get_server(hostname: str, db=Depends(get_db), _=Depends(verify_token)):
    row = await db.fetchrow("SELECT * FROM servers WHERE hostname=$1", hostname)
    if not row:
        raise HTTPException(404, "Not found")
    return dict(row)


@app.patch("/api/admin/update-server/{hostname}")
async def admin_update(hostname: str, patch: ServerPatch, db=Depends(get_db), _=Depends(verify_token)):
    updates = {k: v for k, v in patch.dict().items() if v is not None}
    if not updates:
        raise HTTPException(400, "Nothing to update")
    sets = ", ".join(f"{k}=${i+1}" for i, k in enumerate(updates))
    vals = list(updates.values()) + [hostname]
    await db.execute(f"UPDATE servers SET {sets} WHERE hostname=${len(vals)}", *vals)
    return {"status": "updated"}


@app.delete("/api/admin/delete-server/{hostname}")
async def delete_server(hostname: str, db=Depends(get_db), _=Depends(verify_token)):
    await db.execute("DELETE FROM servers WHERE hostname=$1", hostname)
    return {"status": "deleted"}


@app.get("/api/vm-inventory")
async def vm_inventory(db=Depends(get_db), _=Depends(verify_token)):
    rows = await db.fetch("SELECT * FROM vm_inventory ORDER BY vm_name")
    return [dict(r) for r in rows]


@app.get("/api/patch-status")
async def patch_status(db=Depends(get_db), _=Depends(verify_token)):
    rows = await db.fetch("SELECT patch_status, COUNT(*) as count FROM servers GROUP BY patch_status")
    return [dict(r) for r in rows]


@app.post("/api/sync-inventory")
async def sync_inventory(_=Depends(verify_token)):
    import asyncio
    proc = await asyncio.create_subprocess_shell(
        "ansible-playbook /opt/cbd/ansible/cbd_inventory.yml",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    return {"status": "sync_triggered", "pid": proc.pid}


@app.get("/health")
async def health():
    return {"status": "ok", "ts": datetime.utcnow().isoformat()}
