# CBD SERVER INVENTORY — Complete Deployment Guide
## Production Architecture on RHEL 9.6

---

## 1. SYSTEM ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                      INTERNAL NETWORK                           │
│                                                                 │
│  Linux Servers (RHEL/CentOS/Ubuntu)                             │
│       │                                                         │
│       │ SSH (read-only service account)                         │
│       ▼                                                         │
│  ┌─────────────────────┐                                        │
│  │  Ansible Server     │  ← Collects facts every 6h (cron)     │
│  │  RHEL 9.6           │                                        │
│  │  /opt/cbd/ansible/  │                                        │
│  └──────────┬──────────┘                                        │
│             │ POST /api/server-update (JSON)                    │
│             ▼                                                   │
│  ┌─────────────────────┐                                        │
│  │  FastAPI Backend    │  cbd-api.cbd.local:8000               │
│  │  Python 3.11        │                                        │
│  │  uvicorn + gunicorn │                                        │
│  └──────────┬──────────┘                                        │
│             │ asyncpg                                           │
│             ▼                                                   │
│  ┌─────────────────────┐                                        │
│  │  PostgreSQL 16      │  cbd-db.cbd.local:5432                │
│  └─────────────────────┘                                        │
│                                                                 │
│  ┌─────────────────────┐                                        │
│  │  React Frontend     │  → Built to /opt/tomcat/webapps/ROOT   │
│  │  Tailwind + Recharts│                                        │
│  └──────────┬──────────┘                                        │
│             │                                                   │
│             ▼                                                   │
│  ┌─────────────────────┐                                        │
│  │  Apache Tomcat 10   │  cbd-portal.cbd.local:8080            │
│  │  Serves React SPA   │                                        │
│  └─────────────────────┘                                        │
│                                                                 │
│  VMware vSphere ──── vCenter API (read-only) ──► FastAPI sync  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. BACKEND FOLDER STRUCTURE

```
backend/
├── main.py                  # FastAPI application (all routes)
├── requirements.txt         # Python dependencies
├── .env.example             # Environment variable template
├── models/
│   ├── server.py            # Pydantic models
│   └── vm.py
├── routers/
│   ├── servers.py           # /api/servers routes
│   ├── vms.py               # /api/vm-inventory routes
│   ├── patches.py           # /api/patch-status routes
│   └── admin.py             # /api/admin routes
├── db/
│   ├── connection.py        # asyncpg pool
│   └── schema.sql           # Database schema
└── services/
    ├── ansible_trigger.py   # Ansible sync job trigger
    └── vmware_sync.py       # vSphere API sync (pyVmomi)
```

---

## 3. REACT FRONTEND FOLDER STRUCTURE

```
frontend/
├── public/
│   ├── assets/
│   │   └── logo/
│   │       └── cbd-logo.png      # Place logo here
│   ├── manifest.json             # PWA manifest
│   ├── service-worker.js         # PWA service worker
│   └── offline.html              # PWA offline fallback
├── src/
│   ├── components/
│   │   ├── Sidebar.jsx
│   │   ├── Topbar.jsx
│   │   ├── MetricCard.jsx
│   │   ├── ServerTable.jsx
│   │   ├── VMTable.jsx
│   │   └── Charts/
│   │       ├── PatchTrend.jsx
│   │       ├── OsDistribution.jsx
│   │       ├── ClusterUsage.jsx
│   │       └── VmPowerStates.jsx
│   ├── pages/
│   │   ├── Dashboard.jsx
│   │   ├── Inventory.jsx
│   │   ├── VirtualMachines.jsx
│   │   ├── PatchStatus.jsx
│   │   ├── Snapshots.jsx
│   │   ├── Reports.jsx
│   │   ├── Administration.jsx
│   │   └── Help.jsx
│   ├── hooks/
│   │   ├── useServers.js
│   │   ├── useCounter.js
│   │   └── useTheme.js
│   ├── api/
│   │   └── client.js             # Axios API client
│   ├── App.jsx
│   └── index.jsx
├── tailwind.config.js
├── package.json
└── vite.config.js
```

---

## 4. INSTALLATION — STEP BY STEP

### 4.1 PostgreSQL Setup

```bash
# Install PostgreSQL 16 on RHEL 9
sudo dnf install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-9-x86_64/pgdg-redhat-repo-latest.noarch.rpm
sudo dnf -qy module disable postgresql
sudo dnf install -y postgresql16-server postgresql16

# Initialize and start
sudo /usr/pgsql-16/bin/postgresql-16-setup initdb
sudo systemctl enable --now postgresql-16

# Create DB and user
sudo -u postgres psql <<EOF
CREATE DATABASE cbd_inventory;
CREATE USER cbd_api WITH ENCRYPTED PASSWORD 'CHANGE_THIS_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE cbd_inventory TO cbd_api;
EOF

# Apply schema
psql -U cbd_api -d cbd_inventory -f /opt/cbd/database/schema.sql
```

### 4.2 FastAPI Backend Setup

```bash
# Install Python 3.11
sudo dnf install -y python3.11 python3.11-pip python3.11-devel

# Create app directory and venv
sudo mkdir -p /opt/cbd/backend
sudo python3.11 -m venv /opt/cbd/venv
source /opt/cbd/venv/bin/activate

# Install dependencies
pip install fastapi uvicorn[standard] asyncpg pydantic gunicorn

# Set environment variables (never hard-code!)
cat > /etc/cbd/api.env <<'EOF'
DATABASE_URL=postgresql://cbd_api:CHANGE_THIS_STRONG_PASSWORD@localhost:5432/cbd_inventory
CBD_API_TOKEN=GENERATE_A_STRONG_RANDOM_TOKEN_HERE
EOF
chmod 600 /etc/cbd/api.env

# Create systemd service
cat > /etc/systemd/system/cbd-api.service <<'EOF'
[Unit]
Description=CBD Server Inventory FastAPI
After=network.target postgresql-16.service

[Service]
User=cbd
Group=cbd
WorkingDirectory=/opt/cbd/backend
EnvironmentFile=/etc/cbd/api.env
ExecStart=/opt/cbd/venv/bin/gunicorn main:app \
    --workers 4 \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:8000 \
    --access-logfile /var/log/cbd/api-access.log \
    --error-logfile /var/log/cbd/api-error.log
Restart=always

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now cbd-api
```

### 4.3 React Frontend Build

```bash
# Install Node.js 20 LTS
sudo dnf install -y nodejs npm

# Build frontend
cd /opt/cbd/frontend
npm install
npm run build    # Output: dist/

# Copy to Tomcat webapps
sudo cp -r dist/* /opt/tomcat/webapps/ROOT/
```

### 4.4 Apache Tomcat 10 Setup

```bash
# Download Tomcat 10
cd /opt
sudo wget https://archive.apache.org/dist/tomcat/tomcat-10/v10.1.20/bin/apache-tomcat-10.1.20.tar.gz
sudo tar xzf apache-tomcat-10.1.20.tar.gz
sudo mv apache-tomcat-10.1.20 tomcat
sudo chown -R tomcat:tomcat /opt/tomcat

# Configure for SPA routing — add to server.xml:
# <Valve className="org.apache.catalina.valves.rewrite.RewriteValve"/>
# Create /opt/tomcat/conf/Catalina/localhost/ROOT/rewrite.config:
cat > /opt/tomcat/conf/Catalina/localhost/rewrite.config <<'EOF'
RewriteCond %{REQUEST_URI} !^/api
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^(.*)$ /index.html [L]
EOF

# Create systemd service
cat > /etc/systemd/system/tomcat.service <<'EOF'
[Unit]
Description=Apache Tomcat 10
After=network.target

[Service]
Type=forking
User=tomcat
Group=tomcat
Environment=JAVA_HOME=/usr/lib/jvm/java-17-openjdk
Environment=CATALINA_HOME=/opt/tomcat
ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now tomcat
```

### 4.5 Ansible Setup

```bash
# Install Ansible
sudo dnf install -y ansible-core

# Create service account on all managed servers
sudo useradd -m -s /bin/bash ansible-svc
sudo -u ansible-svc ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""

# Distribute SSH key (run once per server)
ssh-copy-id -i ~/.ssh/id_ed25519.pub ansible-svc@TARGET_SERVER

# Configure inventory
cat > /etc/ansible/hosts <<'EOF'
[all_servers]
srv-prod-001 ansible_host=10.40.1.11
srv-prod-002 ansible_host=10.40.1.12
# ... add all servers

[all:vars]
ansible_user=ansible-svc
ansible_ssh_private_key_file=/home/ansible-svc/.ssh/id_ed25519
EOF

# Schedule every 6 hours via cron
echo "0 */6 * * * ansible-svc ansible-playbook /opt/cbd/ansible/cbd_inventory.yml >> /var/log/cbd/ansible.log 2>&1" \
    | sudo tee /etc/cron.d/cbd-inventory
```

---

## 5. PWA CONFIGURATION

### public/manifest.json
```json
{
  "name": "CBD Server Inventory",
  "short_name": "CBD Inventory",
  "description": "Infrastructure monitoring portal",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#060d1f",
  "theme_color": "#3b82f6",
  "orientation": "any",
  "icons": [
    {"src": "/assets/logo/cbd-logo.png", "sizes": "192x192", "type": "image/png"},
    {"src": "/assets/logo/cbd-logo.png", "sizes": "512x512", "type": "image/png"}
  ]
}
```

### public/service-worker.js (key parts)
```javascript
const CACHE = 'cbd-v1';
const STATIC = ['/', '/index.html', '/offline.html'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(STATIC)));
});

self.addEventListener('fetch', e => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match('/offline.html'))
  );
});
```

---

## 6. ENVIRONMENT VARIABLES REFERENCE

| Variable        | Description                        | Example                          |
|----------------|------------------------------------|----------------------------------|
| DATABASE_URL   | PostgreSQL connection string       | postgresql://user:pass@host/db   |
| CBD_API_TOKEN  | Bearer token for API auth          | (use: openssl rand -hex 32)      |
| VCENTER_HOST   | vCenter hostname                   | vcenter01.cbd.local              |
| VCENTER_USER   | vCenter read-only service account  | svc-cbd-ro@vsphere.local         |
| VCENTER_PASS   | vCenter password (use vault)       | (ansible-vault encrypted)        |

---

## 7. FIREWALL PORTS

```bash
sudo firewall-cmd --permanent --add-port=8000/tcp   # FastAPI
sudo firewall-cmd --permanent --add-port=8080/tcp   # Tomcat / React
sudo firewall-cmd --permanent --add-port=5432/tcp   # PostgreSQL (internal only)
sudo firewall-cmd --reload
```

---

## 8. SUPPORT CONTACT

| Field  | Value             |
|--------|-------------------|
| Name   | Shiranjeevi       |
| Phone  | 7445635183        |
| Team   | CBD DevOps        |

---

*CBD SERVER INVENTORY v1.0 — Built on 100% free, open-source technology*
*RHEL 9.6 · Ansible · FastAPI · PostgreSQL · React · Apache Tomcat*
