-- =============================================================
--  CBD SERVER INVENTORY — PostgreSQL Schema
--  Compatible: PostgreSQL 14+
--  Run: psql -U postgres -d cbd_inventory -f schema.sql
-- =============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- TABLE: servers
CREATE TABLE IF NOT EXISTS servers (
    id               UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    hostname         VARCHAR(255) NOT NULL UNIQUE,
    fqdn             VARCHAR(255),
    ip_address       INET NOT NULL,
    os_name          VARCHAR(100),
    os_version       VARCHAR(50),
    kernel           VARCHAR(100),
    architecture     VARCHAR(20),
    cpu_count        SMALLINT,
    cpu_model        VARCHAR(255),
    memory_gb        NUMERIC(8,2),
    memory_free_gb   NUMERIC(8,2),
    swap_gb          NUMERIC(8,2),
    disk_details     TEXT,
    uptime           VARCHAR(100),
    last_reboot      VARCHAR(100),
    logged_in_users  JSONB   DEFAULT '[]',
    local_users      JSONB   DEFAULT '[]',
    sudo_members     TEXT,
    running_services_count INTEGER,
    selinux_status   VARCHAR(20) DEFAULT 'disabled',
    timezone         VARCHAR(50),
    cluster          VARCHAR(100),
    power_state      VARCHAR(20) DEFAULT 'On',
    patch_status     VARCHAR(50) DEFAULT 'Not Scheduled',
    last_patch_date  DATE,
    enabled_flag     BOOLEAN     DEFAULT TRUE,
    notes            TEXT,
    created_at       TIMESTAMP   DEFAULT NOW(),
    last_seen        TIMESTAMP   DEFAULT NOW(),
    updated_at       TIMESTAMP   DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_servers_hostname ON servers USING gin (hostname gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_servers_ip       ON servers (ip_address);
CREATE INDEX IF NOT EXISTS idx_servers_cluster  ON servers (cluster);
CREATE INDEX IF NOT EXISTS idx_servers_patch    ON servers (patch_status);

-- TABLE: patch_history
CREATE TABLE IF NOT EXISTS patch_history (
    id           UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    server_id    UUID    REFERENCES servers(id) ON DELETE CASCADE,
    hostname     VARCHAR(255),
    patch_date   DATE    NOT NULL,
    status       VARCHAR(50),
    packages     JSONB   DEFAULT '[]',
    output       TEXT,
    duration_s   INTEGER,
    triggered_by VARCHAR(100),
    created_at   TIMESTAMP DEFAULT NOW()
);

-- TABLE: clusters
CREATE TABLE IF NOT EXISTS clusters (
    id          UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    datacenter  VARCHAR(100),
    vcenter     VARCHAR(255),
    description TEXT,
    enabled     BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT NOW()
);

-- TABLE: vm_inventory
CREATE TABLE IF NOT EXISTS vm_inventory (
    id             UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    vm_name        VARCHAR(255) NOT NULL,
    esxi_host      VARCHAR(255),
    cluster_name   VARCHAR(100),
    vcpu           SMALLINT,
    memory_gb      NUMERIC(8,2),
    disk_gb        NUMERIC(8,2),
    power_state    VARCHAR(20) DEFAULT 'On',
    os_name        VARCHAR(100),
    ip_address     INET,
    tools_status   VARCHAR(50) DEFAULT 'OK',
    snapshot_count SMALLINT    DEFAULT 0,
    notes          TEXT,
    created_at     TIMESTAMP   DEFAULT NOW(),
    last_synced    TIMESTAMP   DEFAULT NOW()
);

-- TABLE: snapshots
CREATE TABLE IF NOT EXISTS snapshots (
    id            UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    vm_id         UUID    REFERENCES vm_inventory(id) ON DELETE CASCADE,
    vm_name       VARCHAR(255),
    name          VARCHAR(255),
    description   TEXT,
    size_gb       NUMERIC(8,2),
    snapshot_type VARCHAR(50) DEFAULT 'Manual',
    created_at    TIMESTAMP   DEFAULT NOW()
);

-- TABLE: users (IAM)
CREATE TABLE IF NOT EXISTS users (
    id            UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    username      VARCHAR(100) NOT NULL UNIQUE,
    email         VARCHAR(255) NOT NULL UNIQUE,
    full_name     VARCHAR(255),
    role          VARCHAR(20)  DEFAULT 'Viewer' CHECK (role IN ('Admin','Viewer')),
    password_hash TEXT,
    enabled       BOOLEAN DEFAULT TRUE,
    last_login    TIMESTAMP,
    created_at    TIMESTAMP DEFAULT NOW()
);

-- TABLE: sync_jobs
CREATE TABLE IF NOT EXISTS sync_jobs (
    id             UUID    DEFAULT uuid_generate_v4() PRIMARY KEY,
    job_type       VARCHAR(50),
    status         VARCHAR(20) DEFAULT 'running',
    started_at     TIMESTAMP   DEFAULT NOW(),
    finished_at    TIMESTAMP,
    triggered_by   VARCHAR(100),
    result_summary JSONB
);

-- Seed clusters
INSERT INTO clusters (name, datacenter, vcenter) VALUES
    ('Cluster-A','DC-Primary',  'vcenter01.cbd.local'),
    ('Cluster-B','DC-Primary',  'vcenter01.cbd.local'),
    ('Cluster-C','DC-Secondary','vcenter02.cbd.local'),
    ('Cluster-D','DC-Secondary','vcenter02.cbd.local')
ON CONFLICT DO NOTHING;

-- Seed users
INSERT INTO users (username, email, full_name, role) VALUES
    ('admin',      'admin@cbd.local',      'Administrator','Admin'),
    ('shiranjeevi','shiranjeevi@cbd.local', 'Shiranjeevi',  'Admin'),
    ('viewer',     'viewer@cbd.local',     'Read Only',    'Viewer')
ON CONFLICT DO NOTHING;
