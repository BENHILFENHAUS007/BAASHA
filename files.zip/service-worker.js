// ============================================================
// CBD SERVER INVENTORY — Service Worker (PWA)
// Place this file at: public/service-worker.js
// ============================================================

const CACHE_NAME   = 'cbd-inventory-v1';
const OFFLINE_URL  = '/offline.html';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/offline.html',
  '/assets/logo/cbd-logo.png',
  '/manifest.json',
];

// Install: cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Activate: clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: network-first for API, cache-first for assets
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // API calls: network only (never cache)
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(request));
    return;
  }

  // Navigation: serve app shell
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .catch(() => caches.match(OFFLINE_URL))
    );
    return;
  }

  // Assets: cache-first
  event.respondWith(
    caches.match(request)
      .then(cached => cached || fetch(request).then(response => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        return response;
      }))
      .catch(() => caches.match(OFFLINE_URL))
  );
});

// ============================================================
// public/manifest.json (copy to that file)
// ============================================================
/*
{
  "name": "CBD Server Inventory",
  "short_name": "CBD Inventory",
  "description": "Enterprise infrastructure monitoring portal",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "background_color": "#060d1f",
  "theme_color": "#3b82f6",
  "orientation": "any",
  "categories": ["productivity", "utilities"],
  "icons": [
    {
      "src": "/assets/logo/cbd-logo.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/assets/logo/cbd-logo.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ],
  "screenshots": [
    {
      "src": "/assets/screenshot-desktop.png",
      "sizes": "1280x720",
      "type": "image/png",
      "form_factor": "wide"
    },
    {
      "src": "/assets/screenshot-mobile.png",
      "sizes": "390x844",
      "type": "image/png",
      "form_factor": "narrow"
    }
  ]
}
*/
